letter <- function(i) {a <- LETTERS
sample(a, 1, replace=TRUE)}